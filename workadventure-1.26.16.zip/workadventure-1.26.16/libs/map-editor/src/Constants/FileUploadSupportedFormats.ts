export const fileUploadSupportedFormatForMapStorage = new RegExp(".(pdf|jpg|jpeg|png|gif|webp|bmp|svg)$", "i");
export const FILE_UPLOAD_SUPPORTED_FORMATS_FRONT =
    "application/pdf,image/jpeg,image/png,image/gif,image/webp,image/bmp,image/svg+xml";
