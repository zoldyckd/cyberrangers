export const ENTITY_COLLECTION_FILE = "entities.json";
export const ENTITIES_FOLDER_PATH = "/assets/entities";

export const ENTITIES_FOLDER_PATH_NO_PREFIX = ENTITIES_FOLDER_PATH.slice(1);
