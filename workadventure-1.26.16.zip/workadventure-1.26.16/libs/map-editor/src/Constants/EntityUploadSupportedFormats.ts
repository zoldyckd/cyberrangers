export const entityUploadSupportedFormatForMapStorage = new RegExp(".(jpg|jpeg|png|webp)$", "i");
export const ENTITY_UPLOAD_SUPPORTED_FORMATS_FRONT = "image/png, image/jpeg, image/webp";
