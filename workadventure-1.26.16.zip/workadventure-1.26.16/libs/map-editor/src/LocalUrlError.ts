export class LocalUrlError extends Error {}
