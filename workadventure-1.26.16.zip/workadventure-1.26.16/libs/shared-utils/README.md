# Shared utils for WorkAdventure

A very small library containing the few utility functions that need to be shared between some containers.
