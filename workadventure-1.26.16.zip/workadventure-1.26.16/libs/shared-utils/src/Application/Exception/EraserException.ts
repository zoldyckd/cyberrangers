export class EraserLinkException extends Error {}
