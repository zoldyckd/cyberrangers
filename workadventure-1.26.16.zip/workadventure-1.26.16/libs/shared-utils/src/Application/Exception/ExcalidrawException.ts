export class ExcalidrawException extends Error {}
