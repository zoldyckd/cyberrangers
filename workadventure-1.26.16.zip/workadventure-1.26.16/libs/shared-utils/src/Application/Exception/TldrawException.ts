export class TldrawLinkException extends Error {}
