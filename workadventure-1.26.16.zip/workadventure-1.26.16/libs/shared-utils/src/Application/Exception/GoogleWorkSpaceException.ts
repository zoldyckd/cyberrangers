export class GoogleDocsException extends Error {}

export class GoogleSheetsException extends Error {}

export class GoogleSlidesException extends Error {}
