export class KlaxoonException extends Error {}
