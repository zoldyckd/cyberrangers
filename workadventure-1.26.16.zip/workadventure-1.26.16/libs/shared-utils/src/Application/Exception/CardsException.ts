export class CardsLinkException extends Error {}
