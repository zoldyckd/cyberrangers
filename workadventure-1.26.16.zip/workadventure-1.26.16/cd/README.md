This directory contains files related to Continuous Deployment of WorkAdventure.
Those files are very specific to the Kubernetes setup used for deploying WorkAdventure
in CD. Don't try to use them on your own project.