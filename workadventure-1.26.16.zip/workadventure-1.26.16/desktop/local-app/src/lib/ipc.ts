import type { WorkAdventureLocalAppApi, SettingsData, Server } from "@wa-preload-local-app";

export { WorkAdventureLocalAppApi, SettingsData, Server };

export const api = window?.WAD;
