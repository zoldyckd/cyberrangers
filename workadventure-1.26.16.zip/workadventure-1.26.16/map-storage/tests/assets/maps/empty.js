WA.onInit().then(() => {
    console.log('Scripting API initialized');
});
