export class MapLoadingError extends Error {}
