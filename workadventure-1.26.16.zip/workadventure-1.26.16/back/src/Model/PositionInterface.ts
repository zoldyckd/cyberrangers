export interface PositionInterface {
    x: number;
    y: number;
}
