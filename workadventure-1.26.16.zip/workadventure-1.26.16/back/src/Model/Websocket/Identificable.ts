export interface Identificable {
    userId: number;
}
